// export default 'development'
export default 'production'
// export default 'debug'
